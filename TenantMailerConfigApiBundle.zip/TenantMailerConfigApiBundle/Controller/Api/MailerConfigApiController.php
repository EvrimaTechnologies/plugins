<?php

declare(strict_types=1);

namespace MauticPlugin\TenantMailerConfigApiBundle\Controller\Api;

use Mautic\ApiBundle\Controller\FetchCommonApiController;
use Mautic\CoreBundle\Configurator\Configurator;
use Mautic\CoreBundle\Helper\CacheHelper;
use Mautic\CoreBundle\Helper\CoreParametersHelper;
use Mautic\CoreBundle\Helper\Dsn\Dsn;
use Mautic\EmailBundle\Mailer\Message\MauticMessage;
use Mautic\UserBundle\Entity\User;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Mailer\Transport\TransportInterface;
use Symfony\Component\Mime\Address;

class MailerConfigApiController extends FetchCommonApiController
{
    private function escapePercent(?string $value): ?string
    {
        return null === $value ? null : str_replace('%', '%%', $value);
    }

    // Undo escapePercent(). CoreParametersHelper reads config/local.php directly (a plain
    // include, see Mautic\CoreBundle\Loader\ParameterLoader) and never resolves "%%" itself -
    // only the compiled DI container does that, for service wiring. So values coming back
    // through CoreParametersHelper are always in the still-escaped, on-disk form.
    private function unescapePercent(mixed $value): mixed
    {
        return is_string($value) ? str_replace('%%', '%', $value) : $value;
    }

    private function parseDsn(?string $dsnString): Dsn
    {
        if (empty($dsnString)) {
            return new Dsn('smtp', '');
        }

        try {
            return Dsn::fromString($dsnString);
        } catch (\InvalidArgumentException) {
            return new Dsn('smtp', '');
        }
    }

    public function getAction(CoreParametersHelper $coreParametersHelper): Response
    {
        $user = $this->getUser();
        if (!$user instanceof User || !$user->isAdmin()) {
            return $this->accessDenied();
        }

        $dsn = $this->parseDsn($this->unescapePercent((string) $coreParametersHelper->get('mailer_dsn')));

        $customHeaders = $coreParametersHelper->get('mailer_custom_headers');
        if (is_array($customHeaders)) {
            $customHeaders = array_map(
                fn ($value) => is_string($value) ? $this->unescapePercent($value) : $value,
                $customHeaders
            );
        }

        return new JsonResponse([
            'mailer_from_name'            => $this->unescapePercent($coreParametersHelper->get('mailer_from_name')),
            'mailer_from_email'           => $this->unescapePercent($coreParametersHelper->get('mailer_from_email')),
            'mailer_reply_to_email'       => $this->unescapePercent($coreParametersHelper->get('mailer_reply_to_email')),
            'mailer_return_path'          => $this->unescapePercent($coreParametersHelper->get('mailer_return_path')),
            'mailer_address_length_limit' => $coreParametersHelper->get('mailer_address_length_limit'),
            'mailer_is_owner'             => $coreParametersHelper->get('mailer_is_owner'),
            'mailer_custom_headers'       => $customHeaders,
            'mailer_dsn'                  => [
                'scheme'      => $dsn->getScheme(),
                'host'        => $dsn->getHost(),
                'port'        => $dsn->getPort(),
                'user'        => $dsn->getUser(),
                'hasPassword' => !empty($dsn->getPassword()),
            ],
        ]);
    }

    // Mirrors Mautic\EmailBundle\Controller\AjaxController::sendTestEmailAction - same
    // transport, same hardcoded subject/body translation keys, same success/message JSON
    // shape. Uses the currently saved mailer_dsn (compiled container transport). Unlike
    // core, the recipient is not the logged-in user - API auth (OAuth2/Basic) has no
    // reliable "current user" email (client_credentials tokens aren't tied to a user,
    // and UserHelper::getUser() can return a user with a null email in that context) -
    // so the recipient is passed explicitly in the request body instead.
    public function testAction(Request $request, TransportInterface $transport): Response
    {
        $data = json_decode($request->getContent(), true);
        $to   = is_array($data) ? ($data['email'] ?? null) : null;

        if (!is_string($to) || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
            return $this->badRequest('email is required and must be a valid email address.');
        }

        $email = (new MauticMessage())
            ->subject($this->translator->trans('mautic.email.config.mailer.transport.test_send.subject'))
            ->text($this->translator->trans('mautic.email.config.mailer.transport.test_send.body'))
            ->from(new Address((string) $this->coreParametersHelper->get('mailer_from_email'), (string) $this->coreParametersHelper->get('mailer_from_name') ?: ''))
            ->to(new Address($to));

        $success = true;
        $message = $this->translator->trans('mautic.core.success');

        try {
            $transport->send($email);
        } catch (\Throwable $e) {
            // Broad catch on purpose: transport errors (TransportExceptionInterface) and
            // address/RFC errors (Symfony\Component\Mime\Exception\RfcComplianceException,
            // thrown pre-send during envelope validation) live in different exception trees.
            // Since this endpoint takes attacker/integration-controlled input (mailer_from_email
            // is admin-set but the "to" address is caller-supplied), any failure here should
            // come back as a normal JSON response, never a 500.
            $success = false;
            $message = $e->getMessage();
        }

        return new JsonResponse(['success' => $success, 'message' => $message]);
    }

    public function putAction(Request $request, CoreParametersHelper $coreParametersHelper, Configurator $configurator, CacheHelper $cacheHelper): Response
    {
        $user = $this->getUser();
        if (!$user instanceof User || !$user->isAdmin()) {
            return $this->accessDenied();
        }

        $data = json_decode($request->getContent(), true);
        if (!is_array($data)) {
            return $this->badRequest('Request body must be valid JSON.');
        }

        $fromName  = $data['mailer_from_name'] ?? null;
        $fromEmail = $data['mailer_from_email'] ?? null;
        $replyTo   = $data['mailer_reply_to_email'] ?? null;
        $dsnData   = $data['mailer_dsn'] ?? null;

        if (!is_string($fromName) || '' === $fromName) {
            return $this->badRequest('mailer_from_name is required and must be a string.');
        }

        if (!is_string($fromEmail) || !filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
            return $this->badRequest('mailer_from_email is required and must be a valid email address.');
        }

        if (null !== $replyTo && (!is_string($replyTo) || !filter_var($replyTo, FILTER_VALIDATE_EMAIL))) {
            return $this->badRequest('mailer_reply_to_email must be a valid email address.');
        }

        if (!is_array($dsnData)) {
            return $this->badRequest('mailer_dsn is required.');
        }

        if ('smtp' !== ($dsnData['scheme'] ?? null)) {
            return $this->badRequest('mailer_dsn.scheme must be "smtp".');
        }

        $host = $dsnData['host'] ?? null;
        if (!is_string($host) || '' === $host) {
            return $this->badRequest('mailer_dsn.host is required and must be a string.');
        }

        $customHeaders = $data['mailer_custom_headers'] ?? [];
        if (!is_array($customHeaders)) {
            return $this->badRequest('mailer_custom_headers must be an object/array.');
        }

        $escapedCustomHeaders = [];
        foreach ($customHeaders as $headerName => $headerValue) {
            // Configurator::renderArray() never escapes array keys when writing local.php
            // (only values), so an unvalidated key containing a quote or backslash would
            // corrupt the file's PHP syntax and take the whole site down on next container
            // compile/include - the same failure mode as the DSN "%" issue, via a different field.
            
            if (!is_string($headerName) || !preg_match('/^[A-Za-z0-9\-]+$/', $headerName)) {
                return $this->badRequest('mailer_custom_headers keys must contain only letters, digits, and hyphens.');
            }
            if (!is_string($headerValue)) {
                return $this->badRequest('mailer_custom_headers values must be strings.');
            }
            $escapedCustomHeaders[$headerName] = $this->escapePercent($headerValue);
        }

        // Explicit action instead of presence/value-of-"password" sensing: typed API clients
        // (Go structs, C# DTOs, Java POJOs) often can't omit a JSON field - the serializer
        // emits it with a zero-value regardless - so "omit the field to keep" is unreachable
        // for those callers and silently misbehaves. An explicit enum removes the ambiguity.
        $passwordAction = $dsnData['password_action'] ?? null;
        if (!in_array($passwordAction, ['keep', 'clear', 'set'], true)) {
            return $this->badRequest('mailer_dsn.password_action is required and must be "keep", "clear", or "set".');
        }

        if ('set' === $passwordAction) {
            $password = $dsnData['password'] ?? null;
            if (!is_string($password) || '' === $password) {
                return $this->badRequest('mailer_dsn.password is required and must be a non-empty string when password_action is "set".');
            }
        } elseif ('clear' === $passwordAction) {
            $password = null;
        } else {
            $existingDsn = $this->unescapePercent((string) $coreParametersHelper->get('mailer_dsn'));
            $password    = $this->parseDsn($existingDsn)->getPassword();
            if (null === $password || '' === $password) {
                return $this->badRequest('mailer_dsn.password_action cannot be "keep": no existing password is configured to inherit.');
            }
        }

        $dsnUser = $dsnData['user'] ?? null;
        if (null !== $dsnUser && !is_string($dsnUser)) {
            return $this->badRequest('mailer_dsn.user must be a string.');
        }

        $returnPath = $data['mailer_return_path'] ?? null;
        if (null !== $returnPath && !is_string($returnPath)) {
            return $this->badRequest('mailer_return_path must be a string.');
        }

        $addressLengthLimit = (int) ($data['mailer_address_length_limit'] ?? 320);
        $isOwner    = (bool) ($data['mailer_is_owner'] ?? false);

        $newDsn = new Dsn(
            'smtp',
            $host,
            $dsnUser,
            $password,
            isset($dsnData['port']) ? (int) $dsnData['port'] : null
        );

        // Symfony resolves "%...%" sequences in every container parameter at compile time.
        // URL-encoded DSN passwords (and any free-text field) can contain "%" incidentally
        // (e.g. "+" becomes "%2B"), which Symfony then misreads as a parameter placeholder
        // and fails to compile the container for the whole site. Escape "%" as "%%" for
        // every string value written to local.php so it round-trips through Symfony intact.
        $configurator->mergeParameters([
            'mailer_from_name'            => $this->escapePercent($fromName),
            'mailer_from_email'           => $this->escapePercent($fromEmail),
            'mailer_reply_to_email'       => $this->escapePercent($replyTo),
            'mailer_return_path'          => $this->escapePercent($returnPath),
            'mailer_address_length_limit' => $addressLengthLimit,
            'mailer_is_owner'             => $isOwner,
            'mailer_custom_headers'       => $escapedCustomHeaders,
            'mailer_dsn'                  => $this->escapePercent((string) $newDsn),
        ]);

        try {
            $configurator->write();
        } catch (\RuntimeException $e) {
            return new JsonResponse(['error' => 'Unable to write configuration file.'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }

        $cacheHelper->refreshConfig();

        // Build the response from the unescaped values already in hand rather than
        // re-reading $configurator->getParameters(), which would now hold the "%%"-escaped
        // form written to disk, not the caller's original input.
        return new JsonResponse([
            'mailer_from_name'            => $fromName,
            'mailer_from_email'           => $fromEmail,
            'mailer_reply_to_email'       => $replyTo,
            'mailer_return_path'          => $returnPath,
            'mailer_address_length_limit' => $addressLengthLimit,
            'mailer_is_owner'             => $isOwner,
            'mailer_custom_headers'       => $customHeaders,
            'mailer_dsn'                  => [
                'scheme'      => $newDsn->getScheme(),
                'host'        => $newDsn->getHost(),
                'port'        => $newDsn->getPort(),
                'user'        => $newDsn->getUser(),
                'hasPassword' => !empty($newDsn->getPassword()),
            ],
        ]);
    }
}

<?php

declare(strict_types=1);

namespace MauticPlugin\TenantMailerConfigApiBundle\Controller\Api;

use Mautic\ApiBundle\Controller\FetchCommonApiController;
use Mautic\CoreBundle\Configurator\Configurator;
use Mautic\CoreBundle\Helper\CacheHelper;
use Mautic\CoreBundle\Helper\CoreParametersHelper;
use Mautic\CoreBundle\Helper\Dsn\Dsn;
use Mautic\UserBundle\Entity\User;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class MailerConfigApiController extends FetchCommonApiController
{
    public function getAction(CoreParametersHelper $coreParametersHelper): Response
    {
        $user = $this->getUser();
        if (!$user instanceof User || !$user->isAdmin()) {
            return $this->accessDenied();
        }

        $dsn = Dsn::fromString((string) $coreParametersHelper->get('mailer_dsn'));

        return new JsonResponse([
            'mailer_from_name'            => $coreParametersHelper->get('mailer_from_name'),
            'mailer_from_email'           => $coreParametersHelper->get('mailer_from_email'),
            'mailer_reply_to_email'       => $coreParametersHelper->get('mailer_reply_to_email'),
            'mailer_return_path'          => $coreParametersHelper->get('mailer_return_path'),
            'mailer_address_length_limit' => $coreParametersHelper->get('mailer_address_length_limit'),
            'mailer_is_owner'             => $coreParametersHelper->get('mailer_is_owner'),
            'mailer_custom_headers'       => $coreParametersHelper->get('mailer_custom_headers'),
            'mailer_dsn'                  => [
                'scheme'      => $dsn->getScheme(),
                'host'        => $dsn->getHost(),
                'port'        => $dsn->getPort(),
                'user'        => $dsn->getUser(),
                'hasPassword' => !empty($dsn->getPassword()),
            ],
        ]);
    }

    public function putAction(Request $request, CoreParametersHelper $coreParametersHelper, Configurator $configurator, CacheHelper $cacheHelper): Response
    {
        $user = $this->getUser();
        if (!$user instanceof User || !$user->isAdmin()) {
            return $this->accessDenied();
        }

        $data = json_decode($request->getContent(), true);
        if (!is_array($data)) {
            return $this->badRequest('Request body must be valid JSON.');
        }

        $fromName  = $data['mailer_from_name'] ?? null;
        $fromEmail = $data['mailer_from_email'] ?? null;
        $replyTo   = $data['mailer_reply_to_email'] ?? null;
        $dsnData   = $data['mailer_dsn'] ?? null;

        if (empty($fromName)) {
            return $this->badRequest('mailer_from_name is required.');
        }

        if (empty($fromEmail) || !filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
            return $this->badRequest('mailer_from_email is required and must be a valid email address.');
        }

        if (!empty($replyTo) && !filter_var($replyTo, FILTER_VALIDATE_EMAIL)) {
            return $this->badRequest('mailer_reply_to_email must be a valid email address.');
        }

        if (!is_array($dsnData)) {
            return $this->badRequest('mailer_dsn is required.');
        }

        if ('smtp' !== ($dsnData['scheme'] ?? null)) {
            return $this->badRequest('mailer_dsn.scheme must be "smtp".');
        }

        $host = $dsnData['host'] ?? null;
        if (empty($host)) {
            return $this->badRequest('mailer_dsn.host is required.');
        }

        if (array_key_exists('password', $dsnData)) {
            $password = $dsnData['password'];
            if (empty($password)) {
                return $this->badRequest('mailer_dsn.password cannot be empty when provided; omit the field to keep the existing password.');
            }
        } else {
            $password = Dsn::fromString((string) $coreParametersHelper->get('mailer_dsn'))->getPassword();
        }

        $newDsn = new Dsn(
            'smtp',
            $host,
            $dsnData['user'] ?? null,
            $password,
            isset($dsnData['port']) ? (int) $dsnData['port'] : null
        );

        $configurator->mergeParameters([
            'mailer_from_name'            => $fromName,
            'mailer_from_email'           => $fromEmail,
            'mailer_reply_to_email'       => $replyTo,
            'mailer_return_path'          => $data['mailer_return_path'] ?? null,
            'mailer_address_length_limit' => (int) ($data['mailer_address_length_limit'] ?? 320),
            'mailer_is_owner'             => (bool) ($data['mailer_is_owner'] ?? false),
            'mailer_custom_headers'       => $data['mailer_custom_headers'] ?? [],
            'mailer_dsn'                  => (string) $newDsn,
        ]);

        try {
            $configurator->write();
        } catch (\RuntimeException $e) {
            return new JsonResponse(['error' => 'Unable to write configuration file.'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }

        $cacheHelper->refreshConfig();

        return $this->getAction($coreParametersHelper);
    }
}

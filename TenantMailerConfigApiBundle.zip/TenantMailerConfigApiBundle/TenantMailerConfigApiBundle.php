<?php

declare(strict_types=1);

namespace MauticPlugin\TenantMailerConfigApiBundle;

use Mautic\IntegrationsBundle\Bundle\AbstractPluginBundle;

class TenantMailerConfigApiBundle extends AbstractPluginBundle
{
}

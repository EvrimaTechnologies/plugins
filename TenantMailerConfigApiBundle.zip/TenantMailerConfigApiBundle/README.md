# Tenant Mailer Config API plugin for Mautic 7.x

REST API for Mautic's **Configuration -> Email Settings** screen. Uses the same core services as
the UI Save button (`Configurator::mergeParameters()` / `write()` + `CacheHelper::refreshConfig()`)
so changes apply immediately, no `cache:clear` needed.

Only `smtp` DSN scheme supported.

## Requirements

- Mautic 7.x (single `mailer_dsn` string config).
- API enabled (Configuration -> API Settings), OAuth2 or Basic Auth.
- Authenticated identity must be Mautic **admin** for `GET`/`PUT` (no granular ACL exists for this
  screen in core — same `User::isAdmin()` gate core's `ConfigController` uses).
- `config/local.php` writable by web server.


## Endpoints

### GET /api/config/mailer

Returns current config. Password never returned, only `hasPassword` boolean.

```bash
curl -X GET "https://mautic.example.com/api/config/mailer" -u "user:password"
```

```json
{
  "mailer_from_name": "Acme Corp",
  "mailer_from_email": "no-reply@example.com",
  "mailer_reply_to_email": "support@example.com",
  "mailer_return_path": null,
  "mailer_address_length_limit": 320,
  "mailer_is_owner": true,
  "mailer_custom_headers": {},
  "mailer_dsn": {
    "scheme": "smtp",
    "host": "smtp.example.com",
    "port": 587,
    "user": "smtp-user",
    "hasPassword": true
  }
}
```

### PUT /api/config/mailer

Full replace of all fields except `mailer_dsn.password`:

- omit `password` -> keep existing
- non-empty string -> overwrite
- `null` -> clear it intentionally (matches core UI's blank-the-mask behavior)
- empty string `""` -> always rejected

First-ever `PUT` on a fresh tenant has no existing password to keep, so `password` is required then.

```bash
curl -X PUT "https://mautic.example.com/api/config/mailer" \
  -u "user:password" \
  -H "Content-Type: application/json" \
  -d '{
        "mailer_from_name": "Acme Corp",
        "mailer_from_email": "no-reply@example.com",
        "mailer_reply_to_email": "support@example.com",
        "mailer_address_length_limit": 320,
        "mailer_is_owner": true,
        "mailer_custom_headers": {},
        "mailer_dsn": {
          "scheme": "smtp",
          "host": "smtp.example.com",
          "port": 587,
          "user": "smtp-user",
          "password": "actual-secret-here"
        }
      }'
```

Response: same shape as `GET` (200 OK).

### POST /api/config/mailer/test

Sends test email using **currently saved** config to the caller's own email. Mirrors core's "Send
test email" button exactly (same transport, from/to, subject/body). No request body. No admin
check (see Permissions).

```bash
curl -X POST "https://mautic.example.com/api/config/mailer/test" -u "user:password"
```

```json
{ "success": true, "message": "Success!" }
```

Always 200 — check `success`, not HTTP status. On failure, `message` is the raw transport error.

### Body parameters (PUT)

| Field                       | Type          | Required | Notes                                              |
|-----------------------------|---------------|----------|-----------------------------------------------------|
| `mailer_from_name`          | string        | yes      |                                                     |
| `mailer_from_email`         | string        | yes      | valid email                                        |
| `mailer_reply_to_email`     | string        | no       | valid email if provided                            |
| `mailer_return_path`        | string        | no       |                                                     |
| `mailer_address_length_limit` | int         | no       | default 320                                        |
| `mailer_is_owner`           | bool          | no       | default false                                      |
| `mailer_custom_headers`     | object        | no       | string values only; keys: letters/digits/hyphens only |
| `mailer_dsn.scheme`         | string        | yes      | must be `"smtp"`                                   |
| `mailer_dsn.host`           | string        | yes      |                                                     |
| `mailer_dsn.port`           | int           | no       |                                                     |
| `mailer_dsn.user`           | string        | no       |                                                     |
| `mailer_dsn.password`       | string\|null  | no*      | *required on first configure; omit=keep, null=clear, ""=rejected |

### Status codes

| Status | Meaning                                        |
|--------|--------------------------------------------------|
| 200    | Success                                          |
| 400    | Validation failure                               |
| 403    | Not admin (GET/PUT only)                         |
| 500    | `config/local.php` not writable                  |

## Permissions

`GET`/`PUT` require admin, same as core's Configuration screen.

`POST /test` has **no admin check** — matches core's own `sendTestEmailAction`, which also has
none (unlike its sibling `testMonitoredEmailServerConnectionAction`). Core's UI only hides the
button from non-admins; the action itself was never gated. Revisit if API credentials are ever
handed to non-admin integrations.

## Known pitfalls (fixed)

**`%` in password could crash the whole site** — Symfony treats `%word%` in any config value as a
parameter reference. URL-encoded passwords (`+` -> `%2B`) broke container compile for the entire
site. Fixed via `escapePercent()`/`unescapePercent()` (same approach as core's `EscapeTransformer`).

**`mailer_custom_headers` keys unrestricted** — `Configurator::renderArray()` escapes array values
but not keys; a quote/backslash key would corrupt `local.php`. Fixed by restricting keys to
`^[A-Za-z0-9\-]+$`.

## Out of scope

- Non-SMTP DSN schemes (`smtps`, SES/SendGrid API transports).

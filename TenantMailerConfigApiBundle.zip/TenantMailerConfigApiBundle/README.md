# Tenant Mailer Config API plugin for Mautic 7.x

Exposes Mautic's **Configuration -> Email Settings** screen (Mail Send Settings + Email DSN
sections) as a REST API, so per-tenant SMTP credentials can be pushed programmatically instead of
through the UI. Internally it calls the exact same core services the UI Save button uses
(`Configurator::mergeParameters()` / `Configurator::write()`) and the same cache-refresh call
core's own `ConfigController` makes (`CacheHelper::refreshConfig()`), so config takes effect
immediately — no `cache:clear` needed.

Only the `smtp` DSN scheme is supported.

## Requirements

- Mautic 7.x (mailer config is a single `mailer_dsn` string in this version, not the pre-5.0 split
  `mailer_host`/`mailer_user`/etc. keys — verified against this repo's source, not assumed).
- API enabled in Mautic (Configuration -> API Settings), with OAuth2 (client_credentials grant
  requires the API client to have been created by an admin user) or Basic Auth credentials.
- The authenticated API user (or the OAuth2 client's owning role) must be a Mautic **admin**.
  Mautic's Configuration screen has no granular ACL permission for this (verified: no
  `config:config:*` permission exists anywhere in ConfigBundle) — access is gated by
  `User::isAdmin()`, same as core's own `ConfigController`.
- `config/local.php` must be writable by the web server process.

## Installation

1. Copy the `TenantMailerConfigApiBundle` folder into your Mautic `plugins/` directory.
2. Clear the cache and reload plugins:

   ```bash
   php bin/console cache:clear
   php bin/console mautic:plugins:reload
   ```

3. The plugin appears as **"Tenant Mailer Config API"** under Settings -> Plugins.

## Usage

### GET /api/config/mailer

Returns current mailer configuration. Password is never returned — only a `hasPassword` boolean.

```bash
curl -X GET "https://mautic.example.com/api/config/mailer" -u "user:password"
```

```json
{
  "mailer_from_name": "Acme Corp",
  "mailer_from_email": "no-reply@example.com",
  "mailer_reply_to_email": "support@example.com",
  "mailer_return_path": null,
  "mailer_address_length_limit": 320,
  "mailer_is_owner": true,
  "mailer_custom_headers": {},
  "mailer_dsn": {
    "scheme": "smtp",
    "host": "smtp.example.com",
    "port": 587,
    "user": "smtp-user",
    "hasPassword": true
  }
}
```

### PUT /api/config/mailer

Writes mailer configuration. Full replace of all fields listed below except `mailer_dsn.password`,
which has three distinct states:

- **Omit** the `password` key entirely -> keep the previously saved password unchanged.
- **Provide a non-empty string** -> overwrite it with that value.
- **Provide `null`** -> intentionally clear it (passwordless/no-auth transport), matching what
  core's own Configuration UI allows when you blank out the masked password field.

An empty string (`""`) is always rejected, so an accidental blank value in a payload can't
silently degrade to a no-auth transport the way `null` deliberately can.

On the **very first** `PUT` to a fresh tenant instance there is no existing password to keep, so
`password` becomes required — omitting it returns a 400, not a silent passwordless save.

```bash
curl -X PUT "https://mautic.example.com/api/config/mailer" \
  -u "user:password" \
  -H "Content-Type: application/json" \
  -d '{
        "mailer_from_name": "Acme Corp",
        "mailer_from_email": "no-reply@example.com",
        "mailer_reply_to_email": "support@example.com",
        "mailer_address_length_limit": 320,
        "mailer_is_owner": true,
        "mailer_custom_headers": {},
        "mailer_dsn": {
          "scheme": "smtp",
          "host": "smtp.example.com",
          "port": 587,
          "user": "smtp-user",
          "password": "actual-secret-here"
        }
      }'
```

Response: same shape as `GET`, reflecting the newly saved values (200 OK).

### Body parameters

| Field                          | Type          | Required | Notes                                                         |
|---------------------------------|---------------|----------|----------------------------------------------------------------|
| `mailer_from_name`               | string        | yes      |                                                                  |
| `mailer_from_email`              | string        | yes      | Must be a valid email address                                  |
| `mailer_reply_to_email`          | string        | no       | Must be a valid email address if provided                      |
| `mailer_return_path`             | string        | no       |                                                                  |
| `mailer_address_length_limit`    | int           | no       | Defaults to 320 if omitted                                     |
| `mailer_is_owner`                | bool          | no       | Defaults to false if omitted                                   |
| `mailer_custom_headers`          | object        | no       | String values only; keys limited to letters, digits, hyphens; defaults to `{}` if omitted |
| `mailer_dsn.scheme`              | string        | yes      | Must be exactly `"smtp"`                                        |
| `mailer_dsn.host`                | string        | yes      |                                                                  |
| `mailer_dsn.port`                | int           | no       |                                                                  |
| `mailer_dsn.user`                | string        | no       |                                                                  |
| `mailer_dsn.password`            | string\|null  | no*      | *Required on first-ever configure. Omit to keep existing password; `null` to clear it intentionally; empty string is always rejected |

### Status codes

| Status | Meaning                                                                  |
|--------|---------------------------------------------------------------------------|
| 200    | Success, returns current/updated config                                   |
| 400    | Validation failure (see message) — missing/invalid field                  |
| 403    | Authenticated user (or OAuth2 client's role) is not an admin              |
| 500    | `config/local.php` was not writable                                       |

## Permissions

No granular ACL — requires the authenticated API identity to be a Mautic **admin** role, mirroring
core's own Configuration screen restriction exactly (`ConfigController::editAction`'s
`$this->user->isAdmin()` guard).

## Known pitfalls (fixed)

### `%` in the password could crash the whole site

Mautic writes `config/local.php` values into Symfony's container as parameters. Symfony treats any
`%word%` in a parameter value as a reference to another parameter — a literal `%` must be doubled
(`%%`) or it breaks container compile.

Our DSN password is URL-encoded (`urlencode()`), and AWS SES secret keys often contain `+`/`/`,
which become `%2B`/`%2F`. Writing that unescaped once broke the entire site (not just this API),
with `cache:clear` failing on `non-existent parameter "2BMPx"`.

**Fix:** escape `%` → `%%` before writing (`escapePercent()`), unescape `%%` → `%` when reading
back for API responses (`unescapePercent()`). Same approach Mautic core uses for its own
Configuration form (`EscapeTransformer`).

### `mailer_custom_headers` keys must be restricted

Core's `Configurator::renderArray()` escapes array values but not array keys. A header key with a
quote or backslash would corrupt `config/local.php` the same way. Fixed by only allowing
`^[A-Za-z0-9\-]+$` for header names.

## Not covered (out of scope for this version)

- Non-SMTP DSN schemes (`smtps`, API-based transports like SES/SendGrid) are rejected.

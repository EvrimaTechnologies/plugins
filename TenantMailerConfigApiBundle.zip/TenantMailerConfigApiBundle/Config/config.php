<?php

declare(strict_types=1);

return [
    'name'        => 'Tenant Mailer Config API',
    'description' => 'Exposes Mautic mailer/SMTP configuration (Configuration -> Email Settings) as a REST API: GET/PUT /api/config/mailer, POST /api/config/mailer/test',
    'version'     => '1.0.0',
    'author'      => 'Evrima',
    'routes'      => [
        'main'   => [],
        'public' => [],
        'api'    => [
            'plugin_tenantmailerconfig_get' => [
                'path'       => '/config/mailer',
                'controller' => 'MauticPlugin\TenantMailerConfigApiBundle\Controller\Api\MailerConfigApiController::getAction',
                'method'     => 'GET',
            ],
            'plugin_tenantmailerconfig_put' => [
                'path'       => '/config/mailer',
                'controller' => 'MauticPlugin\TenantMailerConfigApiBundle\Controller\Api\MailerConfigApiController::putAction',
                'method'     => 'PUT',
            ],
            'plugin_tenantmailerconfig_test' => [
                'path'       => '/config/mailer/test',
                'controller' => 'MauticPlugin\TenantMailerConfigApiBundle\Controller\Api\MailerConfigApiController::testAction',
                'method'     => 'POST',
            ],
        ],
    ],
    'services' => [],
    'menu'     => [],
];
